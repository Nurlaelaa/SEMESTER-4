# NaiveBayesApp
Prediksi menggunakan methode klasifikasi Naive Bayes berbasis Aplikasi Android

# Fitur
1. Dataset dapat dirubah, letak dataset berada di folder assets
2. Data testing baru dapat diinputkan langsung dan dipisah menggunakan koma (,)
3. Terdapat proses pengerjaan Naive Bayes beserta hasil yang diperoleh
4. Dataset yang sudah di set di android dapat dilihat melalui aplikasi tersebut dengan mengklik tombol DATASET

# Screenshoot
![screenshot_2019-01-20-19-11-57](https://user-images.githubusercontent.com/44946501/51439063-87084500-1ce7-11e9-8fc9-6463f9ab6abf.png)

![screenshot_2019-01-20-19-11-30](https://user-images.githubusercontent.com/44946501/51439049-4e686b80-1ce7-11e9-9e6a-4cf9058f5ba5.png)

![screenshot_2019-01-20-19-11-39](https://user-images.githubusercontent.com/44946501/51439057-748e0b80-1ce7-11e9-90b1-52dda9893421.png)

![screenshot_2019-01-20-19-11-48](https://user-images.githubusercontent.com/44946501/51439062-87084500-1ce7-11e9-8de6-9217dc961045.png)



# License
MIT License

Copyright (c) 2019 ADITYA NANDA UTAMA

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
